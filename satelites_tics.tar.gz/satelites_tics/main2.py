#principio

from math import *
import sys
import os
from colorama import Fore
import time
from time import sleep


from selenium import webdriver
from selenium.webdriver.common.keys import Keys

#funciones secundarias

def google():
	x = input(Fore.BLUE + "Introduce la primera coordenada de la localización del satélite:")
	y = input(Fore.BLUE + "Introduce la segunda coordenada de la localización del satélite:")

	driver = webdriver.Chrome('./chromedriver')
	driver.get("https://www.google.com/maps/@" + x + "," + y + ",14z")

	time.sleep(6)
	os.system("clear")
	menu()
def banner():
	print("""

                                                                                                   
                                                                     ...                            
                                                                  ..'.....                          
                                                               ........'::.                         
                                           ..               ..'''....,;;,,'...                      
                                        .;lxd,           ....''',,::;,'........                     
                                      'cxOkxd,        .....'..',clcc,........                       
                                     ,dkxoclo:,,.   .........,;;;:,.,,.....                         
                                    ;xdo:;lxOOOOx:'..''.''',;,'......''.                            
                                    .;,..,dkkOOOOOkxc'';clc;..........                              
                                         .lxkkkkxdddl;,',:;'.......                                 
                                          .:dddlloddddxocc:......                                   
                                     ......;:'.,coloxkkkOOo. .                                      
                                 ......'..';c;..;ldxkkkkkkOx:.                                      
                              ...........,coc;;,,coodxkkkkkkk:                                      
                            ..........';;;'''..''...,lxxxxxxko.                                     
                         ....,'..''.;;;,..........   .,clodo:.                                      
                      ........',.;ol:'..........         ...                                        
                   ...........;lc:;;'.........                                                      
                 ...........,;;c:.',........                                                        
               ....'.....';;;'......''...                                                           
                ....';;;;;,.......'....                                                             
                  ...:dl'...........                                                                
                     .''..........                                                                  
                      .........                                                                     
                       ......                                                                       


""")


def menu():
	banner()

	opciones = int(input(Fore.GREEN + """



	MENU:

        1. Cálculo de INTENSIDAD DE CAMPO GRAVITATORIO a la altura del satélite (pulsar 1)
        2. Cálculo de la VELOCIDAD de un satélite en una órbita circular (pulsar 2)
        3. Cálcula de el espacio que recorre el satélite en un tiempo determinado (pulsar 3)
        4. Sitúa en un mapa la posición del satélite según sus coordenadas (pulsar 4)
	5. SALIR (pulsar 5)

        Elige una opción:


	"""))

	if opciones == 1: # primera parte del menú en la que calculamos la intensidad del campo gravitatorio a la altura del satélite
		os.system("clear")

		print(Fore.BLUE + "Cálculo de la intensida del CAMPO GRAVITATORIO que influye en el satélite")
		print("")
		print("")

		intensidad_g() #llamamos a la función con los cálculos para medir la intensidad

	if opciones == 2:
        	os.system("clear")
        	print(Fore.BLUE + "Cálculo de la VELOCIDAD de un satélites")
        	print("")

        	print("")

        	velocidad() #llamamos a la función de la velocidad para poder realizar las ecuaciones

	if opciones == 3:
        	os.system("clear")
        	print(Fore.BLUE + "Cálculo del ESPACIO que recorre un satélite en una determinada cantidad de tiempo")
        	print("")
        	print("")

        	espacio()


	if opciones == 4:

		google()
		time.sleep(4)
		os.system("clear")
		menu()


	else:
		sys.exit # salida del programa por una opción en el menú inválida




def intensidad_g(): #función opción 1 del menu
	# la ecuación es g = G * M/R^2

	radio = float(input(Fore.GREEN + "Introduce el RADIO del satélite respecto al centro del planeta (en m):"))

	z = radio * radio
	y = 5.9e24 / z
	g = 6.67e-11 * y
	print(Fore.RED + "El valor de g en ese punto es:", g, "m/s^2")

	time.sleep(6)
	os.system("clear")
	menu() # vuelta a menú en todas las opciones


def velocidad(): #función opción 2 del menú
	#la ecuación es v=e/t ; e=2*3.14*r

	radio_v = float(input(Fore.GREEN + "Introduce el RADIO del satélite respecto al centro del planeta (en m):"))
	periodo = float(input(Fore.GREEN + "Introuduce el PERÍODO de la óbita (en s):"))

	espacio = radio_v * 6.14

	velo = espacio / periodo
	print(Fore.RED + "La velocidad del satélite es:", velo, "m/s")

	time.sleep(6)
	os.system("clear")
	menu()


def espacio(): #función opción 3 del menú
	#la ecuación es e=v*t

	velocidad_e = float(input(Fore.GREEN+ "Introduce la velocidad del satélite (en m/s):"))
	tiempo_e = float(input(Fore.GREEN+ "Introduce el el tiempo (en s):"))

	espacio_e = velocidad_e / tiempo_e

	print(Fore.RED + "El espacio que recorre el satélite en", tiempo_e, "s", "es:", espacio_e, "m")

	time.sleep(6)
	os.system("clear")
	menu()





def pantalla_de_carga(): # pantalla completa antes de los programas, contiene a banner() y a manu()
	os.system("clear")
	text = "BIENVENIDO/A AL LABORATORIO DE SATÉLITES"
	for c in text: #fonción para generar retardo en la salida del texto
		print(Fore.BLUE + c, end='')
		sys.stdout.flush()
		sleep(0.04)

	#banner()
	menu()







#fin funciones secundarias





#FUNCIONES PRIMARIAS

#FIN FUNCIONES PRIMARIAS







#principal

pantalla_de_carga()

#principal



